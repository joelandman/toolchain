package #
Locale::Codes::LangVar_Retired;

# This file was automatically generated.  Any changes to this file will
# be lost the next time 'deprecate_codes' is run.
#    Generated on: Tue Mar  4 13:19:40 EST 2014

use strict;
require 5.006;
use warnings;
use utf8;

our($VERSION);
$VERSION='3.30';

$Locale::Codes::Retired{'langvar'}{'alpha'}{'code'} = {
};

$Locale::Codes::Retired{'langvar'}{'alpha'}{'name'} = {
   q(slovene in bohoric alphabet) => [ q(bohoric), q(Slovene in Bohoric alphabet) ],
};


1;
