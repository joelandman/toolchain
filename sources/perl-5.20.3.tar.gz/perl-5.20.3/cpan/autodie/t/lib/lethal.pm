package lethal;

# A dummy package showing how we can trivially subclass autodie
# to our tastes.

use base qw(autodie);

1;
